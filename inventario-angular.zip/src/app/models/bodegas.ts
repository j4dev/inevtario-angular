export interface Bodegas {
    nombre: string;
    ciudad: string;
    codigo: string;
}
