export interface Products {
    nombre: string;
    codigo: string;
    descripcion: string;
    precio: string;
    cantidad: string;
}
